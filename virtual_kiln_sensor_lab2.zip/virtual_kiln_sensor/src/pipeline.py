"""Reproducible pipeline for the virtual kiln sensor lab."""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2, kurtosis, normaltest, skew
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

DATA_IDS = {
    "data_train.csv": "1BJ7eIQVOrnEP-v6JctC54TI_c2VlKtDf",
    "target_train.csv": "1FpUfMWi0LcR0SxCQg9cdcWjcuezKafuL",
    "data_test_small.csv": "1POwZC9gGuVGuMl4XRqw7xBND6mXCbrGs",
    "target_test_small.csv": "1pcpkAP6kAhtEeGTb13nOWfKVzzUX2frm",
}


def download_data(data_dir: Path) -> None:
    """Download the four public CSV files if they are not already present."""
    from urllib.request import urlretrieve

    data_dir.mkdir(parents=True, exist_ok=True)
    for name, file_id in DATA_IDS.items():
        path = data_dir / name
        if not path.exists():
            url = f"https://drive.google.com/uc?export=download&id={file_id}"
            print(f"Downloading {name} ...")
            urlretrieve(url, path)


def load_telemetry(path: Path) -> pd.DataFrame:
    """Load minute telemetry; average duplicate timestamps and preserve causality."""
    df = pd.read_csv(path, parse_dates=["datetime"])
    sensor_cols = [f"telemetry_{i}" for i in range(16)]
    for col in sensor_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    # There are repeated timestamps in the source. Averaging only within a
    # timestamp removes duplicate records without using future observations.
    df = df.groupby("datetime", as_index=False)[sensor_cols].mean().sort_values("datetime")
    return df.set_index("datetime")


def load_targets(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["Дата"])
    df = df.rename(columns={"Дата": "datetime"})
    df["target"] = pd.to_numeric(df["target"], errors="coerce")
    return df.dropna(subset=["datetime", "target"]).sort_values("datetime").reset_index(drop=True)


def make_features(telemetry: pd.DataFrame, targets: pd.DataFrame,
                  prior_targets: pd.DataFrame | None = None,
                  telemetry_lag_minutes: int = 0) -> pd.DataFrame:
    """Build only causal features available by each laboratory sample time."""
    dense = [f"telemetry_{i}" for i in range(12)]
    sparse = [f"telemetry_{i}" for i in range(12, 16)]

    # Fill at most two missing minute readings using past values only.
    minute = telemetry[dense].sort_index().asfreq("min").ffill(limit=2)
    blocks = [minute]
    # Trailing windows include the current minute and never look forward.
    for window in (10, 30, 60):
        roll = minute.rolling(f"{window}min", min_periods=max(2, window // 3))
        for stat, frame in (("mean", roll.mean()), ("std", roll.std()),
                            ("min", roll.min()), ("max", roll.max())):
            frame = frame.add_suffix(f"_{stat}_{window}m")
            blocks.append(frame)
    # A 10-minute change is a simple, interpretable rate-of-change feature.
    delta = (minute - minute.shift(10)).add_suffix("_delta_10m")
    blocks.append(delta)
    dense_features = pd.concat(blocks, axis=1).replace([np.inf, -np.inf], np.nan)
    dense_features.index.name = "datetime"

    query = targets[["datetime"]].sort_values("datetime").copy()
    # If `Дата` means lab-result time rather than sample-collection time,
    # align the target with telemetry available 10–15 minutes earlier.
    query["feature_time"] = query["datetime"] - pd.Timedelta(minutes=telemetry_lag_minutes)
    # Match the latest telemetry at or before the label timestamp (at most one
    # minute old for dense sensors). No backward fill is used.
    dense_reset = dense_features.reset_index().rename(columns={"datetime": "sensor_time"}).sort_values("sensor_time")
    feat = pd.merge_asof(query.sort_values("feature_time"), dense_reset, left_on="feature_time", right_on="sensor_time", direction="backward",
                         tolerance=pd.Timedelta("1min"))

    # Four channels are measured only every few hours. Use the most recent
    # reading for up to 120 minutes and expose its age to the estimator.
    for col in sparse:
        # Filter missing rows before as-of matching; otherwise the nearest
        # timestamp can be selected even though that channel has no reading.
        sparse_frame = telemetry[[col]].dropna().copy()
        sparse_frame["sensor_time"] = sparse_frame.index
        sparse_frame = sparse_frame.reset_index(drop=True).sort_values("sensor_time")
        sparse_query = pd.merge_asof(query.sort_values("feature_time"), sparse_frame,
                                     left_on="feature_time", right_on="sensor_time",
                                     direction="backward", tolerance=pd.Timedelta("120min"))
        feat[f"{col}_age_min"] = (sparse_query["feature_time"] - sparse_query["sensor_time"]).dt.total_seconds() / 60
        feat[col] = sparse_query[col]
        feat[f"{col}_available"] = sparse_query[col].notna().astype(int)
    feat = feat.drop(columns=["feature_time", "sensor_time"], errors="ignore")

    # Cyclic clock features encode process shift/time-of-day without an
    # artificial discontinuity at midnight.
    hour = feat["datetime"].dt.hour + feat["datetime"].dt.minute / 60
    dow = feat["datetime"].dt.dayofweek
    feat["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    feat["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    feat["dow_sin"] = np.sin(2 * np.pi * dow / 7)
    feat["dow_cos"] = np.cos(2 * np.pi * dow / 7)

    # Previous laboratory result is usable in operation: labels are at least
    # 60 minutes apart, while the stated lab delay is only 10–15 minutes.
    if prior_targets is None:
        prior_targets = targets
        prev_y = prior_targets["target"].shift(1)
        prev_t = prior_targets["datetime"].shift(1)
    else:
        prior_targets = prior_targets.sort_values("datetime").reset_index(drop=True)
        # `prior_targets` contains earlier known labels followed by the labels
        # being scored. A one-row shift gives only the most recent earlier lab.
        prev_y = prior_targets["target"].shift(1).tail(len(targets)).reset_index(drop=True)
        prev_t = prior_targets["datetime"].shift(1).tail(len(targets)).reset_index(drop=True)
    feat["target_lag_1"] = prev_y.to_numpy()
    feat["target_lag_age_min"] = (feat["datetime"].reset_index(drop=True) - prev_t).dt.total_seconds() / 60
    return feat.set_index("datetime").sort_index()


def metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    nonzero = np.abs(y_true) > 1e-8
    denom = np.abs(y_true).sum()
    direction = np.sign(np.diff(y_true)) == np.sign(np.diff(y_pred))
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": mean_squared_error(y_true, y_pred) ** 0.5,
        "MAPE_pct_nonzero": float(np.mean(np.abs((y_true[nonzero] - y_pred[nonzero]) / y_true[nonzero])) * 100) if nonzero.any() else np.nan,
        "WAPE_pct": float(np.abs(y_true - y_pred).sum() / denom * 100) if denom else np.nan,
        "R2": r2_score(y_true, y_pred),
        "Direction_accuracy_pct": float(direction.mean() * 100) if len(direction) else np.nan,
    }


def residual_diagnostics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    resid = np.asarray(y_true) - np.asarray(y_pred)
    fit = np.asarray(y_pred)
    n = len(resid)
    centered = resid - resid.mean()
    # Breusch-Pagan LM statistic using fitted values as the explanatory term.
    aux = LinearRegression().fit(fit.reshape(-1, 1), resid ** 2)
    r2_aux = aux.score(fit.reshape(-1, 1), resid ** 2)
    jb = normaltest(resid) if n >= 8 else None
    return {
        "residual_mean": float(resid.mean()),
        "residual_std": float(resid.std(ddof=1)),
        "residual_skew": float(skew(resid, bias=False)),
        "residual_excess_kurtosis": float(kurtosis(resid, fisher=True, bias=False)),
        "normaltest_pvalue": float(jb.pvalue) if jb else np.nan,
        "durbin_watson": float(np.sum(np.diff(resid) ** 2) / max(np.sum(resid ** 2), 1e-12)),
        "residual_acf_lag1": float(np.corrcoef(centered[:-1], centered[1:])[0, 1]) if n > 2 else np.nan,
        "breusch_pagan_lm": float(n * r2_aux),
        "breusch_pagan_pvalue": float(chi2.sf(n * r2_aux, 1)),
    }


def run(data_dir: Path, output_dir: Path, telemetry_lag_minutes: int = 0) -> tuple[pd.DataFrame, pd.DataFrame]:
    train_tele = load_telemetry(data_dir / "data_train.csv")
    test_tele = load_telemetry(data_dir / "data_test_small.csv")
    train_y = load_targets(data_dir / "target_train.csv")
    test_y = load_targets(data_dir / "target_test_small.csv")

    # Build train features from train labels only. For sequential test scoring,
    # earlier test lab values become available after their 10–15 min lab delay.
    x_train = make_features(train_tele, train_y, telemetry_lag_minutes=telemetry_lag_minutes)
    known_y = pd.concat([train_y, test_y], ignore_index=True).sort_values("datetime")
    x_test = make_features(test_tele, test_y, prior_targets=known_y,
                           telemetry_lag_minutes=telemetry_lag_minutes)
    feature_cols = list(x_train.columns)
    # One training label is later than the final training telemetry minute.
    # Exclude it rather than imputing an entire contemporaneous sensor row.
    valid_train = x_train[[f"telemetry_{i}" for i in range(12)]].notna().any(axis=1)
    x_train = x_train.loc[valid_train]
    X_train, y_train = x_train[feature_cols], train_y.set_index("datetime").loc[x_train.index, "target"]
    X_test, y_test = x_test[feature_cols], test_y.set_index("datetime").loc[x_test.index, "target"]

    models = {
        "Last_lab_value": None,
        "Linear_regression": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), LinearRegression()),
        "Random_forest": make_pipeline(SimpleImputer(strategy="median"), RandomForestRegressor(
            n_estimators=250, min_samples_leaf=3, max_features=0.8, n_jobs=-1, random_state=42)),
        "Hist_gradient_boosting": make_pipeline(SimpleImputer(strategy="median"), HistGradientBoostingRegressor(
            max_iter=200, learning_rate=0.05, max_leaf_nodes=15, l2_regularization=1.0, random_state=42)),
        "Hist_gradient_boosting_telemetry_only": make_pipeline(SimpleImputer(strategy="median"), HistGradientBoostingRegressor(
            max_iter=200, learning_rate=0.05, max_leaf_nodes=15, l2_regularization=1.0, random_state=42)),
    }
    telemetry_only = [c for c in feature_cols if not c.startswith("target_lag_")]
    model_features = {name: (telemetry_only if name.endswith("telemetry_only") else feature_cols)
                      for name in models}
    results, predictions, runtimes = [], {}, {}
    for name, model in models.items():
        if model is None:
            pred = X_test["target_lag_1"].to_numpy()
            # If the first lab value is absent (not expected for these files),
            # use the training median as a transparent fallback.
            pred = np.where(np.isfinite(pred), pred, float(y_train.median()))
            runtimes[name] = 0.0
        else:
            start = time.perf_counter()
            model.fit(X_train[model_features[name]], y_train)
            fit_s = time.perf_counter() - start
            start = time.perf_counter()
            pred = model.predict(X_test[model_features[name]])
            runtimes[name] = fit_s + time.perf_counter() - start
        predictions[name] = pred
        results.append({"model": name, **metrics(y_test.to_numpy(), pred), "runtime_sec": runtimes[name]})

    # AIC/BIC are meaningful for the Gaussian linear model only, not the tree
    # ensembles. Compute them on the training residuals for that model.
    ols = models["Linear_regression"]
    yhat_train = ols.predict(X_train)
    rss = float(np.sum((y_train.to_numpy() - yhat_train) ** 2))
    n = len(y_train)
    x_design = ols[1].transform(ols[0].transform(X_train))
    design_rank = int(np.linalg.matrix_rank(np.column_stack([np.ones(len(x_design)), x_design])))
    k = design_rank + 1  # design rank plus Gaussian variance
    aic = n * np.log(max(rss / n, 1e-15)) + 2 * k
    bic = n * np.log(max(rss / n, 1e-15)) + k * np.log(n)
    for row in results:
        if row["model"] == "Linear_regression":
            row["train_AIC"] = float(aic)
            row["train_BIC"] = float(bic)

    residual_rows = [{"model": name, **residual_diagnostics(y_test, pred)}
                     for name, pred in predictions.items()]
    output_dir.mkdir(parents=True, exist_ok=True)
    result_df = pd.DataFrame(results).sort_values("RMSE")
    residual_df = pd.DataFrame(residual_rows)
    result_df.to_csv(output_dir / "model_metrics.csv", index=False)
    residual_df.to_csv(output_dir / "residual_diagnostics.csv", index=False)
    pd.DataFrame({"datetime": X_test.index, "target": y_test.to_numpy(), **predictions}).to_csv(
        output_dir / "test_predictions.csv", index=False)

    # Model-agnostic permutation importance on the independent test window.
    forest = models["Random_forest"]
    imp = permutation_importance(forest, X_test, y_test, n_repeats=5, random_state=42,
                                 scoring="neg_mean_absolute_error", n_jobs=-1)
    importance = pd.DataFrame({"feature": feature_cols, "importance_mean": imp.importances_mean,
                               "importance_std": imp.importances_std}).sort_values("importance_mean", ascending=False)
    importance.to_csv(output_dir / "permutation_importance.csv", index=False)
    return result_df, residual_df


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts"))
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    if args.download:
        download_data(args.data_dir)
    metrics_df, diagnostics_df = run(args.data_dir, args.output_dir)
    print(metrics_df.to_string(index=False))
    print("\nResidual diagnostics:\n", diagnostics_df.to_string(index=False))
